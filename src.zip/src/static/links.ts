export const social = {
  x: 'https://twitter.com/invariant_labs',
  github: 'https://github.com/invariant-labs',
  discord: 'https://discord.gg/w6hTeWTJvG',
  telegram: 'https://t.me/Invariant_app',
  medium: 'https://medium.com/@invariant_labs',
  docs: 'https://docs.invariant.app'
}
